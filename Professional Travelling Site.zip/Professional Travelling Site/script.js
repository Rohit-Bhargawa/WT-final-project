const header = document.querySelector('.blurred-header');
const content = document.querySelector('.blurred-content'); // Select the content element

window.addEventListener('scroll', () => {
  const scrollY = window.scrollY;
  const blurValue = Math.min(scrollY / 50, 10);
  
  // Apply blur to the content as you scroll
  content.style.filter = `blur(${blurValue}px)`;
});
